﻿
using Microsoft.AspNetCore.Identity;

namespace BurgerDemo.Model.Identity.Model
{
    public class ApplicationUser : IdentityUser<long>
    {
    }
}
